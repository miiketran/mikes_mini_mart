myApp.factory('OrderFactory', function($http){
  var factory = {};
  var orders = [];
  factory.getOrders = function(callback){
    $http.get('/orders').success(function(output){
      orders = output;
      callback(orders);
    });

  }
  factory.addOrder = function(info, callback){
    $http.post('/add',info).success(function(added_order){
      orders.push({name: added_order.name, product: added_order.product, quantity: added_order.quantity, date: added_order.date})
      callback(orders);
    })
  }
  return factory;
})