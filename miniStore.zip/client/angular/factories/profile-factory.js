myApp.factory('ProfileFactory', function($http){
  var factory = {};
  var profile;
  factory.getProfile = function(id, callback){
    $http.get('/profile/'+ id).success(function(output){
      profile = output;
      callback(profile);
    });
  }
  return factory;
});