(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('ul.tabs').tabs();
  }); // end of document ready
})(jQuery); // end of jQuery name space