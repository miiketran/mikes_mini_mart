// to avoid using 2 controllers on orders partial, inject CustomerFactory
myApp.controller('OrdersController', function($scope, OrderFactory, CustomerFactory, ProductFactory){
  updateOrders();
  updateCustomers();
  updateProducts();
  function updateCustomers(){
    CustomerFactory.getCustomers(function(output){
      $scope.customers = output;
    });
  }
  function updateProducts(){
    ProductFactory.getProducts(function(output) {
      $scope.products = output;
    })
  }
  function updateOrders(){
    OrderFactory.getOrders(function(output){
      $scope.orders = output;
    });
  }
  $scope.addOrder = function(){
    OrderFactory.addOrder($scope.new_order, 
      function(output){
      $scope.orders = output;
      $scope.new_order = {};
      });
  }
  $scope.removeOrder = function(order){
    OrderFactory.removeOrder(order);
  }
})